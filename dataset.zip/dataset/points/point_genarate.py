import matplotlib.pyplot as plt
import random
import pandas as pd
from PIL import Image

# Set the number of random points to generate
num_points = 1000
plane_size = 2000

# List to store coordinates
coordinates = []

# Generate and plot random points
for i in range(num_points):
    x = random.uniform(-plane_size/2, plane_size/2)
    y = random.uniform(-plane_size/2, plane_size/2)
    coordinates.append((x, y))

    # Plotting each point on a separate figure
    plt.figure(figsize=(1, 1), dpi=100)  # Set figure size for saving as image
    plt.scatter(x, y, color='red', s=10)  # Plot the point
    plt.axis('off')  # Turn off axes
    plt.xlim(-plane_size/2, plane_size/2)
    plt.ylim(-plane_size/2, plane_size/2)

    # Save the plot as an image with a unique filename based on coordinates
    filename = f"/Users/dvirani/dp/dataset/points/point_{i}.png"
    plt.savefig(filename, bbox_inches='tight', pad_inches=0)
    plt.close()  # Close the plot to release memory

# Create a DataFrame from the coordinates list
df = pd.DataFrame(coordinates, columns=['x', 'y'])

# Save coordinates to a CSV file
csv_filename = 'point_coordinates.csv'
df.to_csv(csv_filename, index=False)

print(f"{num_points} random points generated and saved.")
print(f"Coordinates saved to {csv_filename}.")
