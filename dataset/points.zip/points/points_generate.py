import matplotlib.pyplot as plt
import random
import pandas as pd
import os

# Set the size of the Cartesian plane and number of red dots to generate
plane_size = 2000
num_dots = 10000 # Generating a single red dot
dot_size = 10  # Size of the red dot

# Create a directory to store the generated images
output_dir = '/Users/dvirani/dp/dataset/points/images'
os.makedirs(output_dir, exist_ok=True)

# List to store coordinates
coordinates = []

# Generate and save each red dot
for i in range(num_dots):
    # Generate random coordinates within the bounds of the plane
    x0 = random.uniform(-(plane_size-300)/2, (plane_size-300)/2)
    y0 = random.uniform(-(plane_size-300)/2, (plane_size-300)/2)

    # Plotting the red dot
    plt.figure(figsize=(1, 1))
    plt.scatter(x0, y0, color='red', s=dot_size)
    plt.axis('off')
    plt.xlim(-2000/2, 2000/2)
    plt.ylim(-2000/2, 2000/2)
    plt.gca().set_aspect('equal', adjustable='box')

    # Save the image
    image_path = os.path.join(output_dir, f'red_dot_{i}.png')
    plt.savefig(image_path)
    plt.close()  # Close the plot to free memory

    # Store coordinates in the list
    coordinates.append({'Image': f'red_dot_{i}.png', 'x': x0, 'y': y0})

# Create a DataFrame from the coordinates list
df = pd.DataFrame(coordinates)

# Save coordinates to CSV
csv_path = '/Users/dvirani/dp/dataset/points/red_dot_coordinates.csv'
df.to_csv(csv_path, index=False)

print(f"Generated {num_dots} red dot and saved its image and coordinates to {csv_path}.")
