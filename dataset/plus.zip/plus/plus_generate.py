import matplotlib.pyplot as plt
import random
import pandas as pd
import os

# Set the size of the Cartesian plane and number of plus signs to generate
plane_size = 2000
num_signs = 10000
arm_length = 250  # Adjust as needed
line_width = 3.0  # Set the desired line width for the plus sign

# Create a directory to store the generated images
output_dir = '/Users/dvirani/dp/dataset/plus/images'
os.makedirs(output_dir, exist_ok=True)

# List to store coordinates
coordinates = []

# Generate and save each plus sign
for i in range(num_signs):
    # Generate random center coordinates within the bounds of the plane
    x0 = random.uniform(-(plane_size-300)/2, (plane_size-300)/2)
    y0 = random.uniform(-(plane_size-300)/2, (plane_size-300)/2)

    # Plotting the plus sign with increased line width on a black background
    plt.figure(figsize=(1, 1), facecolor='black')  # Set black background
    plt.plot([x0 - arm_length, x0 + arm_length], [y0, y0], 'w', linewidth=line_width)  # Horizontal line in white
    plt.plot([x0, x0], [y0 - arm_length, y0 + arm_length], 'w', linewidth=line_width)  # Vertical line in white
    plt.axis('off')
    plt.xlim(-plane_size/2, plane_size/2)
    plt.ylim(-plane_size/2, plane_size/2)
    plt.gca().set_aspect('equal', adjustable='box')

    # Save the image
    image_path = os.path.join(output_dir, f'plus_sign_{i}.png')
    plt.savefig(image_path, facecolor='black')  # Set background color for saved image
    plt.close()  # Close the plot to free memory

    # Store coordinates in the list
    coordinates.append({'Image': f'plus_sign_{i}.png', 'x': x0, 'y': y0})

# Create a DataFrame from the coordinates list
df = pd.DataFrame(coordinates)

# Save coordinates to CSV
csv_path = 'plus_sign_coordinates.csv'
df.to_csv(csv_path, index=False)

print(f"Generated {num_signs} plus signs and saved their images and coordinates to {csv_path}.")
