from flask import Flask, request, jsonify
from flask_cors import CORS
from langchain_community.llms import HuggingFacePipeline
from langchain_community.document_loaders import PyPDFLoader, DirectoryLoader, PDFMinerLoader
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTImage
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS, Chroma
from PIL import Image
import os
import fitz
import PyPDF2
import pdfplumber
import pytesseract
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
import easyocr
from ultralytics import YOLO
from pdf2image import convert_from_path
import accelerate
import base64
import time
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
from transformers import pipeline
import torch
import textwrap
from langchain.llms import HuggingFacePipeline
from langchain.chains import RetrievalQA
from IPython import display
display.clear_output()
import ultralytics
ultralytics.checks()
app = Flask(__name__)
CORS(app) 
processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
model = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-handwritten")

pdf_path = "../uploads/Assignment3.pdf"
input_folder = "../uploads"
output_folder = "../uploadimages"
model_weights = '../modelweights/best.pt'
source = "../uploadimages"

root_folder = "../rootfolder"

ALLOWED_EXTENSIONS = {'pdf'}
app.config['input_folder'] = input_folder

from ultralytics import YOLO
from ultralytics.utils.plotting import Annotator, colors
import cv2
import os

def get_yolo_images(model_weights, source):
  model = YOLO(model_weights)
  names = model.names

  image_dir = source
  assert os.path.exists(image_dir), "Image directory not found"

  output_dir = "ultralytics_crop"
  if not os.path.exists(output_dir):
      os.mkdir(output_dir)

  for image_file in os.listdir(image_dir):
      if image_file.endswith(('.jpg', '.jpeg', '.png', '.bmp')):
          image_path = os.path.join(image_dir, image_file)
          im0 = cv2.imread(image_path)
          if im0 is None:
              continue

          results = model.predict(im0, show=False)
          boxes = results[0].boxes.xyxy.cpu().tolist()
          clss = results[0].boxes.cls.cpu().tolist()

          for i, (box, cls) in enumerate(zip(boxes, clss)):
              class_name = names[int(cls)]
              class_output_dir = os.path.join(output_dir, class_name)
              if not os.path.exists(class_output_dir):
                  os.mkdir(class_output_dir)

              annotator = Annotator(im0, line_width=2, example=names)
              annotator.box_label(box, color=colors(int(cls), True), label=class_name)

              crop_obj = im0[int(box[1]):int(box[3]), int(box[0]):int(box[2])]

              output_file = f"{os.path.splitext(image_file)[0]}{class_name}{i}.png"
              output_path = os.path.join(class_output_dir, output_file)
              cv2.imwrite(output_path, crop_obj)

  cv2.destroyAllWindows()

def data_ingestion(input_folder, output_folder):
  for root, dirs, files in os.walk(input_folder):
      for file in files:
          if file.endswith(".pdf"):
            pdf_path = os.path.join(root, file)
            print("Processing:", pdf_path)
            loader = PDFMinerLoader(pdf_path, extract_images = False)

            # Create output folder if it doesn't exist
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)

            # Open the PDF file
            pdf_document = fitz.open(pdf_path)
            for page_number in range(pdf_document.page_count):
                # Get the page
                page = pdf_document.load_page(page_number)
                # Convert the page to a pixmap (image)
                pixmap = page.get_pixmap()
                # Create image path
                image_name = f"{os.path.splitext(file)[0]}_page_{page_number + 1}.jpg"  # Example: "document.pdf_page_1.jpg"
                image_path = os.path.join(output_folder, image_name)
                # Save the pixmap as an image (JPEG format)
                pixmap.save(image_path)
            # Close the PDF document
            pdf_document.close()

  get_yolo_images(model_weights,output_folder)
  image_dict = create_image_dict(root_folder)
  print(image_dict)

  documents = loader.load()
  text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=500, length_function=len)
  texts = text_splitter.split_documents(documents)
  #create embeddings here
  embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
  print(embeddings)
  #create vector store here
  db = FAISS.from_documents(texts, embeddings)

  db.save_local()

  return db

def image_base_info(image_path):

    # Create an EasyOCR reader object
    reader = easyocr.Reader(['en',])  # Specify the language(s) you want to recognize
    # Read text from the image
    result = reader.readtext(image_path)
    # Extract and concatenate the recognized text
    ocr_text = ' '.join([entry[1] for entry in result])

    return ocr_text

def extract_info_from_filename(filename):
    # Remove file extension
    filename = os.path.splitext(filename)[0]

    # Split the filename to extract page number and file number
    parts = filename.split('_')
    print(parts)
    file_number = parts[1]
    page_number = parts[3]

    # Use regular expression to extract the first numeric part
    match = re.search(r'^(\d+)', page_number)
    if match:
        numeric_part = match.group(1)

    return {
        'file_number': file_number,
        'page_number': numeric_part,
    }

# Define a function to create the dictionary
def create_image_dict(root_folder):
    image_dict = {}
    page_numbers = {}  # Track page numbers to assign the same page number to all images on a page

    # Iterate through each folder containing classified images
    for folder_name in os.listdir(root_folder):
        folder_path = os.path.join(root_folder, folder_name)

        # Check if the item is a directory
        if os.path.isdir(folder_path):
            # Iterate through each image file in the folder
            for filename in os.listdir(folder_path):
                # Extract information from the filename
                image_info = extract_info_from_filename(filename)

                # Check if the page number has been assigned for this page filename
                if image_info['page_number'] not in page_numbers:
                    page_numbers[image_info['page_number']] = len(page_numbers) + 1

                # Assign the page number
                page_number = page_numbers[image_info['page_number']]

                # Create reference number in the format fileno.-pageno.-imageno.
                reference_number = f"{image_info['file_number']}-{page_number}-{len(image_dict) + 1}"

                image_path = os.path.join(folder_path, filename)

                # Create a dictionary entry using the file name as the key
                image_key = os.path.splitext(filename)[0]  # Remove the file extension
                image_dict[image_key] = {
                    'page_number': page_number,
                    'reference_number': reference_number,
                    'base_info': image_base_info(image_path),
                    'class': folder_name
                }

    return image_dict

device = torch.device('cpu')
checkpoint = "MBZUAI/LaMini-T5-738M"
print(f"Checkpoint path: {checkpoint}")  # Add this line for debugging
tokenizer = AutoTokenizer.from_pretrained(checkpoint)
base_model = AutoModelForSeq2SeqLM.from_pretrained(
    checkpoint,
    torch_dtype=torch.float32
)

def llm_pipeline():
    pipe = pipeline(
        'text2text-generation',
        model = base_model,
        tokenizer = tokenizer,
        max_length = 1000,
        do_sample = True,
        temperature = 0.3,
        top_p= 0.95,
        device=device
    )
    local_llm = HuggingFacePipeline(pipeline=pipe)
    return local_llm

def qa_llm():
    llm = llm_pipeline()
    embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
    db = Chroma(persist_directory="db", embedding_function = embeddings)
    retriever = db.as_retriever()
    qa = RetrievalQA.from_chain_type(
        llm = llm,
        chain_type = "stuff",
        retriever = retriever,
        return_source_documents=True
    )
    return qa

def process_answer(instruction):
    response = ''
    instruction = instruction
    qa = qa_llm()
    data_ingestion(input_folder, output_folder)
    generated_text = qa(instruction)
    answer = generated_text['result']
    return answer

# print(process_answer("What is braking control"))

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['file']

    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['input_folder'], filename))
        file_path = os.path.join(app.config['input_folder'], filename)

        return jsonify({'file_path': file_path})

@app.route('/ask_question', methods=['POST'])
def ask_question():
    data = request.json
    file_path = data.get('file_path')
    question = data.get('question')

    if not file_path:
        return jsonify({'error': 'File path not provided'})
    document_path = file_path
    answer = process_answer
    return jsonify({'answer': answer})

if __name__ == '__main__':
    app.run(debug=True, port=4000)